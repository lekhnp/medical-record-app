import { GET_INVOICES_DONE } from "../actions/invoicesAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const invoicesReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_INVOICES_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
  }
};