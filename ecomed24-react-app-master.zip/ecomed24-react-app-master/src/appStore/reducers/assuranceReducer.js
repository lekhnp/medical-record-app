import { GET_ASSURANCE_DONE, POST_ASSURANCE_DONE } from "../actions/assuranceAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const assuranceReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_ASSURANCE_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
        case POST_ASSURANCE_DONE:
          return {
            ...state,
            data: action.payload.data,
            status: action.payload.status,
            error: null
          };
    default:
      return { ...state };
  }
};