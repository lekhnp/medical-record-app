import { GET_HEALTH_ISSUES_DONE, POST_HEALTH_ISSUE_DONE } from "../actions/healthIssuesAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const healthIssuesReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_HEALTH_ISSUES_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
      case POST_HEALTH_ISSUE_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
  }
};