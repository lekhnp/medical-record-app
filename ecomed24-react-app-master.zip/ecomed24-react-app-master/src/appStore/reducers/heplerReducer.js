import { GET_ASSURANCE_ORGANIATION_DONE, GET_DOCTOR_LIST_DONE, GET_HELPER_SERVICE } from "../actions/helperAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const helperReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_DOCTOR_LIST_DONE:
      return {
        doctorList: {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
        }
      };
    case GET_ASSURANCE_ORGANIATION_DONE:
      return {
        assuranceorganation: {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
        }
      };
      case GET_HELPER_SERVICE:
      return {
     
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
     
      };
    default:
      return { ...state };
  }
};