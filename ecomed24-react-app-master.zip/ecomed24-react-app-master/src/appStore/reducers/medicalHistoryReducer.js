import { GET_MEDICAL_HISTORY_DONE } from "../actions/medicalHistoryAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const medicalHistoryReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_MEDICAL_HISTORY_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
  }
};