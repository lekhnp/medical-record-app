import { GET_PATIENT_DETAILS_DONE, UPDATE_PATIENT_DETAILS_DONE, UPDATE_PATIENT_DETAILS_RESET } from "../actions/patientDetailsAction";

const initState = {
  get : {
    data: null,
    error: null,
    status: null,
    message: null,
  },
  update : {
    data: null,
    error: null,
    status: null,
    message: null,
  }
};

export const patientDetailsReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_PATIENT_DETAILS_DONE:
      return {
        ...state,
        get: {
          data: action.payload.data[0],
          status: action.payload.status,
          message: action.payload.message,
          error: null
        }
      };
    case UPDATE_PATIENT_DETAILS_DONE:
        return {
          ...state,
          update: {
            data: action.payload.data,
            status: action.payload.status,
            message: action.payload.message,
            error: null
          }
        };
      case UPDATE_PATIENT_DETAILS_RESET:
          return {
            ...state,
            update: {
              data: null,
              error: null,
              status: null,
              message: null
            }
          };
    default:
      return { ...state };
  }
};