import { GET_VITAL_SIGNS_DONE, POST_VITAL_SIGNS_DONE } from "../actions/vitalSignsAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const vitalSignsReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_VITAL_SIGNS_DONE:
      return {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
      };
    case POST_VITAL_SIGNS_DONE:
      return {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
      };
    default:
      return { ...state };
  }
};