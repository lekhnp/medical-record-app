import { GET_DEPENDENTS_DONE, UPDATE_DEPENDENTS_DONE } from "../actions/dependentsAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const dependentsReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_DEPENDENTS_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
      case UPDATE_DEPENDENTS_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
  }
};