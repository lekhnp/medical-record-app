import { GET_APPOINMENTS_DONE, UPDATE_ADD_APPOINTMENT_DONE } from "../actions/appoinmentsAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const appoinmentsReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_APPOINMENTS_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
      case UPDATE_ADD_APPOINTMENT_DONE:
        return {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
        };

  }
};