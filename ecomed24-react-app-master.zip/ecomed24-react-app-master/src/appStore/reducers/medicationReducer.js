import { GET_MEDICATION_DONE, POST_MEDICATION_DONE } from "../actions/medicationAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const medicationReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_MEDICATION_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    case POST_MEDICATION_DONE:
      return {
        ...state,
        data: action.payload.data,
        status: action.payload.status,
        error: null
      };
    default:
      return { ...state };
  }
};