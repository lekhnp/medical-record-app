import { SET_AUTH_STATUS } from "../actions/authAction";
import { RESET_AUTH_STATUS } from "../actions/authAction";

const initState = {
  status: null,
  message: null,
};

export const authReducer = (state = initState, action) => {
  switch (action.type) {
    case SET_AUTH_STATUS:
      return {
        ...state,
        message: action.payload.message,
        status: action.payload.status,
      };
    case RESET_AUTH_STATUS:
        return {
            ...state,
            message: null,
            status: null,
        };
    default:
      return { ...state };
  }
};