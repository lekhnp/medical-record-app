import { DELETE_ATTACHMENTS_API_URL, GET_ATTACHMENTS_DONE, POST_ATTACHMENTS_DONE } from "../actions/attachmentsAction";

const initState = {
  data: [],
  error: null,
  status: null
};

export const attachmentsReducer = (state = initState, action) => {
  switch (action.type) {
    case GET_ATTACHMENTS_DONE:
      return {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
      };
    case POST_ATTACHMENTS_DONE:
      return {
          ...state,
          data: action.payload.data,
          status: action.payload.status,
          error: null
      };
      case DELETE_ATTACHMENTS_API_URL:
        return {
            ...state,
            data: action.payload.data,
            status: action.payload.status,
            error: null
        };
    default:
      return { ...state };
  }
};