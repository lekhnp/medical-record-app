import { setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_APPOINMENTS_DONE = "GET_APPOINMENTS_DONE";
export const UPDATE_ADD_APPOINTMENT_DONE = "UPDATE_ADD_APPOINT_DETAILS-DONE";
export const DELETE_APPOINTMENT_DONE = "APPOINTMENT DELETED DONE";

export const GET_APPOINMENTS_API_URL = `${APP_API_URL}/patient/appointments`;
export const UPDATE_ADD_APPOINTMENT_API_URL = `${APP_API_URL}/patient/appointment/add`;
export const DELETE_APPOINTMENT_API_URL = `${APP_API_URL}/patient/appointment/delete`;

export const getAppoinments = (uniqueID) => {
  let API_URL = GET_APPOINMENTS_API_URL;
  if (uniqueID) API_URL = `${API_URL}?uniqueID=${uniqueID}`;
  return (dispatch) => {
    return fetch(API_URL, {
      headers: setRequestHeader(),
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: GET_APPOINMENTS_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  };
};

export const updateAddAppointment = (formData) => {
  var formBody = [];
  for (var property in formData) {
    var encodedKey = encodeURIComponent(property);
    var encodedValue = encodeURIComponent(formData[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");

  let API_URL = UPDATE_ADD_APPOINTMENT_API_URL;
  return (dispatch) => {
    return fetch(API_URL, {
      method: 'post',
      body: formBody,
      headers: setRequestHeader('urlencoded')
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: UPDATE_ADD_APPOINTMENT_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  }
}

export const deleteAppointmet = (appointment_id) => {
  let API_URL = DELETE_APPOINTMENT_API_URL;
  if (appointment_id) {
    API_URL = `${API_URL}/${appointment_id}`
  }
  return (dispatch) => {
    return fetch(API_URL, {
      method: 'delete',
      headers: setRequestHeader('urlencoded')
    }).then((res) => res.json())
      .then((data) => {
        if (data && data.status === 1) {
          dispatch({
            type: DELETE_APPOINTMENT_DONE,
            payload: data
          })
        } else if (data.status === 0) {
          dispatch({
            type: SET_AUTH_STATUS,
            payload: data,
          })
        }
      }).catch((err) => {
        console.log(err)
      })
  }
}