import { setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_ASSURANCE_DONE = "GET_ASSURANCE_DONE";
export const POST_ASSURANCE_DONE = "GET_ASSURANCE_DONE";

export const GET_ASSURANCE_API_URL = `${APP_API_URL}/patient/get-assurance`
export const POST_ASSURANCE_API_URL = `${APP_API_URL}/patient/assurance/add`


export const getAssurance = (uniqueID) => {
  let API_URL = GET_ASSURANCE_API_URL;
  if (uniqueID) API_URL = `${API_URL}/${uniqueID}`;
  return (dispatch) => {
    return fetch(API_URL, {
      headers: setRequestHeader(),
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: GET_ASSURANCE_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  };
};
 
export const postAssurance = (formData) => {
  var formBody = [];
  for (var property in formData) {
    var encodedKey = encodeURIComponent(property);
    var encodedValue = encodeURIComponent(formData[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");

  let API_URL = POST_ASSURANCE_API_URL;
  return (dispatch) => {
    return fetch(API_URL, {
      method: 'post',
      body: formBody,
      headers: setRequestHeader('urlencoded')
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: POST_ASSURANCE_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  }
}