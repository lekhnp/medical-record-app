import {setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_MEDICAL_HISTORY_DONE = "GET_MEDICAL_HISTORY_DONE";

export const GET_MEDICAL_HISTORY_API_URL = `${APP_API_URL}/patient/medical-history`

export const getMedicalHistory = (uniqueID) => {
    let API_URL = GET_MEDICAL_HISTORY_API_URL;
    if(uniqueID) API_URL = `${API_URL}?uniqueID=${uniqueID}`;
    return (dispatch) => {
      return fetch(API_URL, {
        headers: setRequestHeader(),
      })
        .then((response) => response.json())
        .then(
          (data) => {
            if (
              data &&
              (data.status === 1)
            ) {
              dispatch({
                type: GET_MEDICAL_HISTORY_DONE,
                payload: data,
              });
            } else if(data && data.status === 0) {
              dispatch({
                type: SET_AUTH_STATUS,
                payload: data,
              });
            }
          },
          (error) => {
          }
        );
    };
  };