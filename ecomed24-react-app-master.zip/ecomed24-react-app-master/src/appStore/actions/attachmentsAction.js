import {setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_ATTACHMENTS_DONE = "GET_ATTACHMENTS_DONE";
export const POST_ATTACHMENTS_DONE ="POST_ATTACHMETS_DONE"
export const DELETE_ATTACHMENTS_DONE ="DELETE_ATTACHMETS_DONE"


export const GET_ATTACHMENTS_API_URL = `${APP_API_URL}/patient/get-attachments`
export const POST_ATTACHMENTS_API_URL = `${APP_API_URL}/patient/attachment/add`
export const DELETE_ATTACHMENTS_API_URL = `${APP_API_URL}/patient/attachment/delete`




export const getAttachments = (uniqueID) => {
    let API_URL = GET_ATTACHMENTS_API_URL;
    if(uniqueID) API_URL = `${API_URL}?uniqueID=${uniqueID}`;
    return (dispatch) => {
      return fetch(API_URL, {
        headers: setRequestHeader(),
      })
        .then((response) => response.json())
        .then(
          (data) => {
            if (
              data &&
              (data.status === 1)
            ) {
              dispatch({
                type: GET_ATTACHMENTS_DONE,
                payload: data,
              });
            } else if(data && data.status === 0) {
              dispatch({
                type: SET_AUTH_STATUS,
                payload: data,
              });
            }
          },
          (error) => {
          }
        );
    };
  };

  export const addAttachments = (formData) => {
    var formBody = [];
    for (var property in formData) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(formData[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");
  
    let API_URL = POST_ATTACHMENTS_API_URL;
    return (dispatch) => {
      return fetch(API_URL, {
        method: "post",
        body: formBody,
        headers: setRequestHeader("urlencoded"),
      })
        .then((response) => response.json())
        .then(
          (data) => {
            if (data) {
              dispatch({
                type: POST_ATTACHMENTS_DONE,
                payload: data,
              });
            } else if(data && data.status === 0) {
              dispatch({
                type: SET_AUTH_STATUS,
                payload: data,
              });
            }
          },
          (error) => {
          }
        );
    };
  };

  export const deleteAttachment = (attachment_id) => {
    let API_URL = DELETE_ATTACHMENTS_API_URL;
    if (attachment_id) {
      API_URL = `${API_URL}/${attachment_id}`
    }
    return (dispatch) => {
      return fetch(API_URL, {
        method: 'delete',
        headers: setRequestHeader('urlencoded')
      }).then((res) => res.json())
        .then((data) => {
          if (data && data.status === 1) {
            dispatch({
              type: DELETE_ATTACHMENTS_DONE,
              payload: data
            })
          } else if (data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            })
          }
        }).catch((err) => {
          console.log(err)
        })
    }
  }