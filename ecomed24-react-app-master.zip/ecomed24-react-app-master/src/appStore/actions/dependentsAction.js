import {setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_DEPENDENTS_DONE = "GET_DEPENDENTS_DONE";
export const UPDATE_DEPENDENTS_DONE = "GET_DEPENDENTS_DONE";


export const GET_DEPENDENTS_API_URL = `${APP_API_URL}/patient/dependants`
export const ADD_DEPENDENTS_API_URL = `${APP_API_URL}/patient/dependant/add`


export const getDependents = (uniqueID) => {
    let API_URL = GET_DEPENDENTS_API_URL;
    if(uniqueID) API_URL = `${API_URL}/${uniqueID}`;
    return (dispatch) => {
      return fetch(API_URL, {
        headers: setRequestHeader(),
      })
        .then((response) => response.json())
        .then(
          (data) => {
            if (
              data &&
              (data.status === 1)
            ) {
              dispatch({
                type: GET_DEPENDENTS_DONE,
                payload: data,
              });
            } else if(data && data.status === 0) {
              dispatch({
                type: SET_AUTH_STATUS,
                payload: data,
              });
            }
          },
          (error) => {
          }
        );
    };
  };

  export const AddDependent = (formData) => {
    var formBody = [];
    for (var property in formData) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(formData[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");
  
    let API_URL = ADD_DEPENDENTS_API_URL;
    return (dispatch) => {
      return fetch(API_URL, {
        method: 'post',
        body: formBody,
        headers: setRequestHeader('urlencoded')
      })
        .then((response) => response.json())
        .then(
          (data) => {
            if (
              data &&
              (data.status === 1)
            ) {
              dispatch({
                type: UPDATE_DEPENDENTS_DONE,
                payload: data,
              });
            } else if (data && data.status === 0) {
              dispatch({
                type: SET_AUTH_STATUS,
                payload: data,
              });
            }
          },
          (error) => {
          }
        );
    }
  }
