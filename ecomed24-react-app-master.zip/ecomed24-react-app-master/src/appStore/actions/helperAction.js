import { setRequestHeader } from "../../utils/helpers";
import { APP_API_URL } from "../../utils/appContants";
import { SET_AUTH_STATUS } from "./authAction";

export const GET_DOCTOR_LIST_DONE = 'GET_DOCTOR_LSIT_DDONE'
export const GET_ASSURANCE_ORGANIATION_DONE = "GET_ASSURANCE_ORGANATION_DONE";

export const GET_DOCTOR_LIST_API_URL = `${APP_API_URL}/helper/get-doctors`
export const GET_ASSURANCE_ORGANIATION_API = `${APP_API_URL}/patient/assurance/organizations`
export const GET_HELPER_SERVICE = `${APP_API_URL}/helper/get-services`


export const getDoctorList = () => {
  let API_URL = GET_DOCTOR_LIST_API_URL;
  return (dispatch) => {
    return fetch(API_URL, {
      headers: setRequestHeader(),
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: GET_DOCTOR_LIST_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  };
};

export const getAssuranceOrganition = () => {
  let API_URL = GET_ASSURANCE_ORGANIATION_API;
  return (dispatch) => {
    return fetch(API_URL, {
      headers: setRequestHeader(),
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: GET_ASSURANCE_ORGANIATION_DONE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  };
};
export const getService = () => {
  let API_URL = GET_HELPER_SERVICE;
  return (dispatch) => {
    return fetch(API_URL, {
      headers: setRequestHeader(),
    })
      .then((response) => response.json())
      .then(
        (data) => {
          if (
            data &&
            (data.status === 1)
          ) {
            dispatch({
              type: GET_HELPER_SERVICE,
              payload: data,
            });
          } else if (data && data.status === 0) {
            dispatch({
              type: SET_AUTH_STATUS,
              payload: data,
            });
          }
        },
        (error) => {
        }
      );
  };
};