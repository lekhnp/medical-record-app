import { configureStore } from '@reduxjs/toolkit';

import { authReducer } from './reducers/authReducer';
import { patientDetailsReducer } from './reducers/patientDetailsReducer';
import { appoinmentsReducer } from './reducers/appoimnentsReducer';
import { invoicesReducer } from './reducers/invoicesReducer';
import { dependentsReducer } from './reducers/dependentsReducer';
import { assuranceReducer } from './reducers/assuranceReducer';
import { attachmentsReducer } from './reducers/attachmentsReducer';
import { vitalSignsReducer } from './reducers/vitalSignsReducer';
import { medicationReducer } from './reducers/medicationReducer';
import { healthIssuesReducer } from './reducers/healthIssuesReducer';
import { medicalHistoryReducer } from './reducers/medicalHistoryReducer';
import { helperReducer } from './reducers/heplerReducer';

export default configureStore({
  reducer: {
    auth: authReducer,
    patientDetails: patientDetailsReducer,
    appoinments: appoinmentsReducer,
    invoices: invoicesReducer,
    dependents: dependentsReducer,
    assurance: assuranceReducer,
    attachments: attachmentsReducer,
    vitalSigns: vitalSignsReducer,
    medication: medicationReducer,
    healthIssues: healthIssuesReducer,
    medicalHistory: medicalHistoryReducer,
    helper:helperReducer
  },
})