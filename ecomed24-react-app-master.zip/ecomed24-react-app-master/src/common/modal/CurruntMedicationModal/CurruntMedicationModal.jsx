import React from 'react'
import { useState,useLayoutEffect } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getAppoinments, updateAddAppointment } from '../../../appStore/actions/appoinmentsAction';
import TextArea from 'antd/es/input/TextArea';
import { addMediction, getMedication } from '../../../appStore/actions/medicationAction';
import { getDoctorList } from '../../../appStore/actions/helperAction';


const CurruntMedicationModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose,patientData } = props;
    const labels = t('CurruntMedication', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();
    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        if (values.date) {
            values.date = values.date['$d'].getTime();
        }
        let formData = {
            ...values,
            patient_id: patientId,
            doctor_id:17
        };
        dispatch(addMediction(formData))
        dispatch(getMedication(patientId))
        handleClose()
        if (updateAddAppointment.status === 1) {
            dispatch(getAppoinments(patientId))
            handleClose()
        }
        if (updateAddAppointment.status === 0) {
            dispatch(getAppoinments(patientId))
            handleClose()
        }
    };
    useLayoutEffect(() => {
        dispatch(getDoctorList())
    }, [dispatch,opened])
    return (
        <Modal
        open={opened}
        title={labels.title}
        onOk={handleClose}
        onCancel={handleClose}
        footer={[]}
        centered
        width={400}
    >
        <Form
            layout="vertical"
            validateMessages={validateMessages}
            onFinish={onFinish}
            fields={fields}
        >
            <Row gutter={24}>
                <Col span={24}>
                    <Form.Item
                        label={labels.patient}
                    >
                        <Input  disabled = {true} placeholder ={patientData?.name}/>
                    </Form.Item>
                </Col>
            </Row>
            <Row gutter={24}>
                <Col span={24}>
                    <Form.Item
                        name="content"
                        label={labels.Current_medications}  
                    >
                        <TextArea rows={4} />
                    </Form.Item>
                </Col>
            </Row>

            <div>
                <Button type="primary" htmlType="submit">
                    {commonLabels.validate}
                </Button>
            </div>
        </Form>
    </Modal>
    )
}

export default CurruntMedicationModal