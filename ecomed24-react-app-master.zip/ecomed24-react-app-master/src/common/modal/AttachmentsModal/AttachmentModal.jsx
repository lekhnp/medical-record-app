import React from 'react'
import { useState } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
    Select,
    Upload
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { AVILABLE_SLOTS } from '../../../utils/dropdowns';
import { Option } from 'antd/es/mentions';
import { UploadOutlined } from '@ant-design/icons';
import { addAttachments } from '../../../appStore/actions/attachmentsAction';

const AttachmentModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose,serviseData } = props;
    const labels = t('addattachment', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();
    const [file, setFile] = useState(null)
    let inputRef = React.useRef(null);

    const validateMessages = {
        required: '${label} is required!'
    };
 
    const onFinish = (values) => {
        let formData = {
            ...values,
            uniqueID: patientId,
          
        };
        console.log(formData)
        // dispatch(addAttachments(formData))
    };
    return (
        <Modal
            open={opened}
            title={labels.addattachments}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={600}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="hospital"
                            label={labels.hospitalName}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="priscribing_doctor"
                            label={labels.prescribingDoctor}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="time_slot"
                            label={labels.kind}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {serviseData.map((ele) => (
                                    <Option value={ele.code_service} key={ele.code_service}>
                                        {ele.name_service}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="document"
                            label={labels.document}
                        >
                            <Upload {...props}>
                                <Button icon={<UploadOutlined />}>Click to Upload</Button>
                            </Upload>
                        </Form.Item>
                    </Col>
                </Row>
                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default AttachmentModal