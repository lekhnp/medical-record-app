import { useState, useEffect } from 'react';
import {
	Modal,
	Row,
	Col,
	Form,
	Input,
	Button,
	Select,
	DatePicker,
	InputNumber,
	Checkbox,
	Radio
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { GENDER, REGION, BLOOD_TYPE, RELIGION } from '../../../utils/dropdowns';
import {
	updatePatientDetails,
	getPatientDetails
} from '../../../appStore/actions/patientDetailsAction';
import { useParams } from 'react-router-dom';

const { Option } = Select;

const EditMedicalRecordModalComponent = (props) => {
	const { t } = useTranslation();
	const { opened, handleClose, patientDetails } = props;
	const labels = t('editMedicalRecord', { returnObjects: true });
	const formLabels = t('generalInfoTab', { returnObjects: true });
	const commonLabels = t('common', { returnObjects: true });
	const [fields, setFields] = useState([]);
	const [checkedOtherInfo, setCheckedOtherInfo] = useState(false);
	const dispatch = useDispatch();
	const { patientId } = useParams();

	const patientUpdate = useSelector((state) => state.patientDetails.update);

	const validateMessages = {
		required: '${label} is required!'
	};

	const onFinish = (values) => {
		console.log(values);
		let formData = {
			...values,
			uniqueID: patientDetails.id
		};
		dispatch(updatePatientDetails(formData));
	};

	useEffect(() => {
		const fieldData = [
			{
				name: 'name',
				value: patientDetails.name.split(' ')[0]
			},
			{
				name: 'last_name',
				value: patientDetails.name.split(' ')[1]
			},
			{
				name: 'sex',
				value: patientDetails.gender
			},
			{
				name: 'age',
				value: patientDetails.age
			},
			{
				name: 'phone',
				value: patientDetails.phone
			},
			{
				name: 'email',
				value: patientDetails.email
			},
			{
				name: 'passport',
				value: patientDetails.code
			},
			{
				name: 'address',
				value: patientDetails.address
			},
			{
				name: 'region',
				value: patientDetails.region
			},
			{
				name: 'register',
				value: patientDetails.register
			},
			{
				name: 'grade',
				value: patientDetails.grade
			},
			{
				name: 'bloodgroup',
				value: patientDetails.blood_type
			},
			{
				name: 'birth_position',
				value: patientDetails.birth_place
			},
			{
				name: 'emergency_contact_name',
				value: patientDetails.nom_contact
			},
			{
				name: 'emergency_contact_no',
				value: patientDetails.phone_contact
			},
			{
				name: 'religion',
				value: patientDetails.religion
			}
		];
		setFields(fieldData);

		if (patientUpdate.status === 1) {
			dispatch(getPatientDetails(patientId));
			handleClose();
		} else if (patientUpdate.status === 0) {
			alert(patientUpdate.message);
			handleClose();
		}
	}, [patientDetails, patientUpdate, handleClose, patientId, dispatch]);

	return (
		<Modal
			open={opened}
			title={labels.editPatient}
			onOk={handleClose}
			onCancel={handleClose}
			footer={[]}
			centered
			width={900}
		>
			<Form
				layout="vertical"
				validateMessages={validateMessages}
				onFinish={onFinish}
				fields={fields}
			>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name="name"
							label={labels.forename}
							rules={[
								{
									required: true
								}
							]}
						>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item
							name="last_name"
							label={labels.name}
							rules={[
								{
									required: true
								}
							]}
						>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item
							name="sex"
							label={labels.sex}
							rules={[
								{
									required: true
								}
							]}
						>
							<Select allowClear>
								{GENDER.map((sex) => (
									<Option value={sex.value} key={sex.value}>
										{sex.option}
									</Option>
								))}
							</Select>
						</Form.Item>
					</Col>
					<Col span={5}>
						<Form.Item name="birthdate" label={labels.dateOfBirth}>
							<DatePicker />
						</Form.Item>
					</Col>
					<Col span={3}>
						<Form.Item name="age" label={labels.age}>
							<InputNumber />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item
							name="phone"
							label={labels.telephone}
							rules={[
								{
									required: true
								}
							]}
						>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item name="email" label={labels.email}>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item name="passport" label={labels.passportNo}>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item name="address" label={formLabels.address}>
							<Input />
						</Form.Item>
					</Col>
					<Col span={8}>
						<Form.Item name="region" label={formLabels.region}>
							<Select allowClear>
								{REGION.map((region) => (
									<Option
										value={region.value}
										key={region.value}
									>
										{region.option}
									</Option>
								))}
							</Select>
						</Form.Item>
					</Col>
					<Col span={24}>
						<Checkbox
							checked={checkedOtherInfo}
							onChange={(e) =>
								setCheckedOtherInfo(e.target.checked)
							}
						>
							{formLabels.otherInfo}
						</Checkbox>
					</Col>
					<Col span={24}>&nbsp;</Col>
				</Row>
				{checkedOtherInfo && (
					<Row gutter={16}>
						<Col span={24}>
							<Form.Item name="otherInfoType">
								<Radio.Group>
									<Radio value="civilian">
										{formLabels.civilian}
									</Radio>
									<Radio value="military">
										{formLabels.military}
									</Radio>
								</Radio.Group>
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="register"
								label={formLabels.register}
							>
								<Input />
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item name="grade" label={formLabels.rank}>
								<Input />
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="bloodgroup"
								label={formLabels.bloodType}
							>
								<Select allowClear>
									{BLOOD_TYPE.map((bType) => (
										<Option
											value={bType.value}
											key={bType.value}
										>
											{bType.option}
										</Option>
									))}
								</Select>
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="birth_position"
								label={formLabels.placeOfBirth}
							>
								<Input />
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="nom_contact"
								label={formLabels.nameToNotify}
							>
								<Input />
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="phone_contact"
								label={formLabels.phoneToNotify}
							>
								<Input />
							</Form.Item>
						</Col>
						<Col span={8}>
							<Form.Item
								name="religion"
								label={formLabels.religion}
							>
								<Select allowClear>
									{RELIGION.map((religion) => (
										<Option
											value={religion.value}
											key={religion.value}
										>
											{religion.option}
										</Option>
									))}
								</Select>
							</Form.Item>
						</Col>
					</Row>
				)}

				<div>
					<Button type="primary" htmlType="submit">
						{commonLabels.validate}
					</Button>
				</div>
			</Form>
		</Modal>
	);
};

export default EditMedicalRecordModalComponent;
