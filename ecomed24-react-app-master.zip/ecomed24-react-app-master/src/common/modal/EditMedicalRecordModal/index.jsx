export { default } from './EditMedicalRecordModalComponent';
