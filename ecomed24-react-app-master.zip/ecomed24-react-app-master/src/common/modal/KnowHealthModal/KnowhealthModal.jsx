import React from 'react'
import { useState, useEffect } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getAppoinments, updateAddAppointment } from '../../../appStore/actions/appoinmentsAction';
import TextArea from 'antd/es/input/TextArea';
import { addKnowHealthissue, getHealthIssues } from '../../../appStore/actions/healthIssuesAction';


const KnowhealthModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose,patientData } = props;
    const labels = t('knowhealthissue', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();
    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        if (values.date) {
            values.date = values.date['$d'].getTime();
        }
        let formData = {
            ...values,
            patient_id: patientId,
            doctor_id:17
        };
        console.log(formData)
        dispatch(addKnowHealthissue(formData))
        dispatch(getHealthIssues(patientId))
        handleClose()
        if (updateAddAppointment.status === 1) {
            console.log("this is working ")
            dispatch(getAppoinments(patientId))
            handleClose()
        }
        if (updateAddAppointment.status === 0) {
            dispatch(getAppoinments(patientId))
            handleClose()
        }
    };
    return (
        <Modal
            open={opened}
            title={labels.title}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={400}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={24}>
                    <Col span={24}>
                        <Form.Item
                            // name="patientname"
                            label={labels.patient}
                            
                        >
                            <Input  disabled = {true} placeholder={patientData?.name}/>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={24}>
                    <Col span={24}>
                        <Form.Item
                            name="content"
                            label={labels.Known_pre_conditions}  
                        >
                            <TextArea rows={4} />
                        </Form.Item>
                    </Col>
                </Row>

                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default KnowhealthModal