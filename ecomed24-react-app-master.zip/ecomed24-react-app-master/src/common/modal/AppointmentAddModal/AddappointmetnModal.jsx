import React from 'react'
import { useState, useEffect } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
    Select,
    DatePicker, 
    Space
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { AVILABLE_SLOTS, PENDING_CONFERMITION, SERVICES } from '../../../utils/dropdowns';
import { Option } from 'antd/es/mentions';
import { getAppoinments, updateAddAppointment } from '../../../appStore/actions/appoinmentsAction';
import { dateConvertor } from '../../../utils/DateConvertor';

const AddappointmetnModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose } = props;
    const labels = t('addoppintmentRecord', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();
    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        if (values.date) {
            let date = dateConvertor(values.date)
            values.date = date
        }
        let formData = {
            ...values,
            uniqueID: patientId
        };
        dispatch(updateAddAppointment(formData))
        dispatch(getAppoinments(patientId))
        handleClose()
        // if (updateAddAppointment.status === 1) {
        //     dispatch(getAppoinments(patientId))
        //     handleClose()
        // }
        // if (updateAddAppointment.status === 0) {
        //     dispatch(getAppoinments(patientId))
        //     handleClose()
        // }
    };
    return (
        <Modal
            open={opened}
            title={labels.addappointment}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={900}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={16}>
                    <Col span={8}>
                        <Form.Item
                            name="patientname"
                            label={labels.patient}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="servicename"
                            label={labels.service}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {SERVICES.map((ele) => (
                                    <Option value={ele.value} key={ele.value}>
                                        {ele.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item name="date"
                            label={labels.date}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <DatePicker />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={8}>
                        <Form.Item
                            name="time_slot"
                            label={labels.available_slots}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {AVILABLE_SLOTS.map((ele) => (
                                    <Option value={ele.value} key={ele.value}>
                                        {ele.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="status"
                            label={labels.status}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {PENDING_CONFERMITION.map((ele) => (
                                    <Option value={ele.value} key={ele.value}>
                                        {ele.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="remarks"
                            label={labels.remarks}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>

                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default AddappointmetnModal