import React from 'react'
import { useState } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { postVitalSign } from '../../../appStore/actions/vitalSignsAction';

const AddvitalSigns = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose , patientData } = props;
    const labels = t('vitalSignsTab', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();

    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        let formData = {
            ...values,
            uniqueID: patientId,
            patient_name:patientData?.name,
            patient_address:patientData?.address,
            patient_phone:patientData?.phone,
            // date_string:Date.now,
            // date:Date.now()
        };
        console.log(formData)
        dispatch(postVitalSign(formData))
    };
    return (
        <Modal
            open={opened}
            title={labels.title}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={600}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="frequenceRespiratoire"
                            label={labels.respiratoryRate}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="frequenceCardiaque"
                            label={labels.heartRate}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="saturationArterielle"
                            label={labels.saturation}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="temperature"
                            label={labels.temperature}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <text>{labels.bloodPressure}</text>
                <Row gutter={16}>
                    <Col span={8}>
                        <Form.Item
                            name="systolique"
                            label={labels.T_stolic}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="diastolique"
                            label={labels.T_diastolic}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item
                            name="temperature"
                            label={labels.result}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input disabled/>
                        </Form.Item>
                    </Col>
                </Row>
                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default AddvitalSigns