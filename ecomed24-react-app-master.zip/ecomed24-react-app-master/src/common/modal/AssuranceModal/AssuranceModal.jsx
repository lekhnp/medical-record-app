import React from 'react'
import { useState, useEffect } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
    DatePicker,
    Select,

} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { dateConvertor } from '../../../utils/DateConvertor';
import { getAssurance, postAssurance } from '../../../appStore/actions/assuranceAction';
import { Option } from 'antd/es/mentions';
const AssuranceModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose, assuranceorganiationData } = props;
    const labels = t('assurance', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const dispatch = useDispatch();
    const { patientId } = useParams();

    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        if (values.date_valid) {
            let date = dateConvertor(values.date_valid)
            values.date_valid = date
        }
        let formData = {
            ...values,
            patient_id: patientId
        };
        dispatch(postAssurance(formData))
        dispatch(getAssurance(patientId))
        handleClose()

    };
    return (
        <Modal
            open={opened}
            title={labels.title}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={600}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="nom_mutuelle"
                            label={labels.title}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {assuranceorganiationData.map((ele) => (
                                    <Option value={ele.id} key={ele.id}>
                                        {ele.nom}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="num_police"
                            label={labels.policy_number}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="charge_mutuelle"
                            label={labels.Supported}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="date_valid"
                            label={labels.Validity_date}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <DatePicker />
                        </Form.Item>
                    </Col>
                </Row>
                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default AssuranceModal