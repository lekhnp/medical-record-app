import React from 'react'
import { useState, useEffect } from 'react';
import {
    Modal,
    Row,
    Col,
    Form,
    Input,
    Button,
    Select,
    DatePicker,
    InputNumber,
    Checkbox,
    Radio,
    Upload
} from 'antd';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { AVILABLE_SLOTS, BLOOD_TYPE, GENDER, PENDING_CONFERMITION, RELATIONSHIP, RELIGION, SERVICES } from '../../../utils/dropdowns';
import { Option } from 'antd/es/mentions';
import { updateAddAppointment } from '../../../appStore/actions/appoinmentsAction';
import { UploadOutlined } from '@ant-design/icons';
import { AddDependent, getDependents } from '../../../appStore/actions/dependentsAction';
import { dateConvertor } from '../../../utils/DateConvertor';

const DependentModal = (props) => {
    const { t } = useTranslation();
    const { opened, handleClose } = props;
    const labels = t('adddependent', { returnObjects: true });
    const formLabels = t('generalInfoTab', { returnObjects: true });
    const commonLabels = t('common', { returnObjects: true });
    const [fields, setFields] = useState([]);
    const [checkedOtherInfo, setCheckedOtherInfo] = useState(false);
    const dispatch = useDispatch();
    const { patientId } = useParams();

    const validateMessages = {
        required: '${label} is required!'
    };
    const onFinish = (values) => {
        if (values.birthdate) {
            let dateofbirth = dateConvertor(values.birthdate['$d'])
            values.birthdate = dateofbirth
        }
        let formData = {
            ...values,
            parent_id: patientId,
        };
        dispatch(AddDependent(formData))
        dispatch(getDependents(patientId))
        handleClose()
    };
    return (
        <Modal
            open={opened}
            title={labels.dependent}
            onOk={handleClose}
            onCancel={handleClose}
            footer={[]}
            centered
            width={600}
        >
            <Form
                layout="vertical"
                validateMessages={validateMessages}
                onFinish={onFinish}
                fields={fields}
            >
                <Row gutter={24}>
                    <Col span={24}>
                        <Form.Item
                            name="relation_type"
                            label={labels.relationship}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {RELATIONSHIP.map((ele) => (
                                    <Option value={ele.value} key={ele.value}>
                                        {ele.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="name"
                            label={labels.fristname}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="last_name"
                            label={labels.name}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="sex"
                            label={labels.sex}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {GENDER.map((sex) => (
                                    <Option value={sex.value} key={sex.value}>
                                        {sex.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col span={8}>
                        <Form.Item name="birthdate" label={labels.dateOfBirth}>
                            <DatePicker />
                        </Form.Item>
                    </Col>
                    <Col span={4}>
                        <Form.Item name="age" label={labels.age}>
                            <InputNumber />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="phone"
                            label={labels.phonenumber}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="email"
                            label={labels.email}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            name="address"
                            label={labels.address}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            name="region"
                            label={labels.region}
                            rules={[
                                {
                                    required: true
                                }
                            ]}
                        >
                            <Select allowClear>
                                {RELIGION.map((ele) => (
                                    <Option value={ele.value} key={ele.value}>
                                        {ele.option}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Col span={24}>
                    <Checkbox
                        checked={checkedOtherInfo}
                        onChange={(e) =>
                            setCheckedOtherInfo(e.target.checked)
                        }
                    >
                        {formLabels.otherInfo}
                    </Checkbox>
                </Col>
                <Col span={24}>&nbsp;</Col>
                {checkedOtherInfo && (
                    <Row gutter={16}>
                        <Col span={12}>
                            <Form.Item
                                name="bloodgroup"
                                label={formLabels.bloodType}
                            >
                                <Select allowClear>
                                    {BLOOD_TYPE.map((bType) => (
                                        <Option
                                            value={bType.value}
                                            key={bType.value}
                                        >
                                            {bType.option}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col span={12}>
                            <Form.Item
                                name="birth_position"
                                label={formLabels.placeOfBirth}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="register"
                                label={labels.registrationNumber}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="grade"
                                label={labels.grade}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="nom_contact"
                                label={formLabels.nameToNotify}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="phone_contact"
                                label={formLabels.phoneToNotify}
                            >
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="religion"
                                label={formLabels.religion}
                            >
                                <Select allowClear>
                                    {RELIGION.map((religion) => (
                                        <Option
                                            value={religion.value}
                                            key={religion.value}
                                        >
                                            {religion.option}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>
                        {/* <Col span={12}>
                            <Form.Item
                                name="img_url"
                                label={labels.picture}
                            >
                                <Upload>
                                    <Button icon={<UploadOutlined />}>Click to Upload</Button>
                                </Upload>
                            </Form.Item>
                        </Col> */}
                    </Row>
                )}
                <div>
                    <Button type="primary" htmlType="submit">
                        {commonLabels.validate}
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}

export default DependentModal