const styles = {
	footerRoot: {
		padding: '10px',
		textAlign: 'center'
	}
};
const FooterComponent = () => {
	return <div style={styles.footerRoot}>2023 © Powered by ecoMed24.</div>;
};

export default FooterComponent;
