export { default } from './GeneralInfoTabComponent';
