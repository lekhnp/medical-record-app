import { Row, Col, Typography } from 'antd';
import { blue } from '@ant-design/colors';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';

const { Title, Text } = Typography;

const styles = {
	sectionLabel: {
		margin: '0px',
		position: 'relative',
		fontWeight: '500',
		textTransform: 'uppercase',
		fontSize: '14px'
	},
	hrLine: {
		position: 'absolute',
		width: '100%',
		height: '1px',
		top: '50%',
		background: blue.primary
	},
	textBg: {
		background: 'white',
		position: 'relative',
		paddingRight: '10px',
		color: blue.primary
	},
	infoContainer: {
		padding: '12px 12px 16px'
	},
	infoLabel: {
		fontSize: '13px',
		paddingBottom: '6px'
	},
	infoValue: {
		fontSize: '13px',
		fontWeight: '500',
		paddingBottom: '6px'
	}
};

const GeneralInfoTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('generalInfoTab', { returnObjects: true });
	const patientData = useSelector((state) => state.patientDetails.get.data);
	
	return (
		patientData && (
			<Row gutter={24}>
				<Col span={12}>
					<Title level={5} style={styles.sectionLabel}>
						<div style={styles.hrLine}></div>
						<Text style={styles.textBg}>{labels.contact}</Text>
					</Title>
					<Row style={styles.infoContainer}>
						<Col span={9} style={styles.infoLabel}>
							{labels.email}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.email}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.phoneNumber}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.phone}</span>
						</Col>
					</Row>

					<Title level={5} style={styles.sectionLabel}>
						<div style={styles.hrLine}></div>
						<Text style={styles.textBg}>{labels.address}</Text>
					</Title>
					<Row style={styles.infoContainer}>
						<Col span={9} style={styles.infoLabel}>
							{labels.address}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.address}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.town}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>Biarritz</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.region}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.region}</span>
						</Col>
					</Row>
				</Col>

				<Col span={12}>
					<Title level={5} style={styles.sectionLabel}>
						<div style={styles.hrLine}></div>
						<Text style={styles.textBg}>
							{labels.otherInfo} ({labels.military})
						</Text>
					</Title>
					<Row style={styles.infoContainer}>
						<Col span={9} style={styles.infoLabel}>
							{labels.register}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.register}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.rank}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.grade}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.bloodType}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.blood_type}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.placeOfBirth}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.birth_place}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.nameToNotify}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp;{' '}
							<span>{patientData.emergency_contact_name}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.phoneToNotify}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp;{' '}
							<span>{patientData.emergency_contact_no}</span>
						</Col>

						<Col span={9} style={styles.infoLabel}>
							{labels.religion}
						</Col>
						<Col span={15} style={styles.infoValue}>
							: &nbsp; <span>{patientData.religion}</span>
						</Col>
					</Row>
				</Col>
			</Row>
		)
	);
};

export default GeneralInfoTabComponent;
