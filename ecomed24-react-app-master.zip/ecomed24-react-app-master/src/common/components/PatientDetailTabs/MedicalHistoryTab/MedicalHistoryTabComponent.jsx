import { Button, Row, Col, Card } from 'antd';
import { AppstoreAddOutlined } from '@ant-design/icons';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getMedicalHistory } from '../../../../appStore/actions/medicalHistoryAction';

const { Meta } = Card;

const MedicalHistoryTabComponent = () => {
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const medicalHistoryData = useSelector(
		(state) => state.medicalHistory.data
	);

	const styles = {
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		column: {
			paddingBottom: '16px'
		},
		secondaryText: {
			fontWeight: 'normal',
			paddingTop: '5px',
			fontSize: '14px'
		}
	};
	const data = [1, 2, 3, 4, 5, 6];

	useEffect(() => {
		dispatch(getMedicalHistory(patientId));
	}, [dispatch, patientId]);
	console.log("medicalHistoryData",medicalHistoryData)
	return (
		<div>
			<div style={styles.topActionButtons}>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}>
					ADD
				</Button>
			</div>
			<Row gutter={16}>
				{data.map((element) => {
					return (
						<Col span={12} key={element} style={styles.column}>
							<Card>
								<Meta
									avatar={<AppstoreAddOutlined />}
									title={
										<>
											<div>Medical Consultation</div>
											<div style={styles.secondaryText}>
												National Reference Laboratory of
												Mycobacteria/PNT
											</div>
										</>
									}
									description="Ibnou Diagne Managing Physician on 07 Apr 2023 08:34:45 PM"
								/>
							</Card>
						</Col>
					);
				})}
			</Row>
		</div>
	);
};

export default MedicalHistoryTabComponent;
