export { default } from './MedicalHistoryTabComponent';
