export { default } from './PatientDetailTabsComponent';
