import { Table, Button, Input, Row, Col, Card } from 'antd';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { AppstoreAddOutlined, CloseSquareOutlined } from '@ant-design/icons';

import {
	Chart as ChartJS,
	CategoryScale,
	LinearScale,
	PointElement,
	LineElement,
	Title,
	Tooltip,
	Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getVitalSigns } from '../../../../appStore/actions/vitalSignsAction';
import AddvitalSigns from '../../../modal/vitalsigns/vitalsignsModal';

const { Search } = Input;
const { Meta } = Card;

ChartJS.register(
	CategoryScale,
	LinearScale,
	PointElement,
	LineElement,
	Title,
	Tooltip,
	Legend
);

const VitalSignsTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('patientDetailTabs', { returnObjects: true });
	const vitalSignslabels = t('vitalSignsTab', { returnObjects: true });
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const vitalSignsData = useSelector((state) => state.vitalSigns.data);
	const [open, setOpen] = useState(false)
	const [sortedInfo, setSortedInfo] = useState({});
	const patientData = useSelector((state) => state.patientDetails.get.data);
	const handleChange = (pagination, filters, sorter) => {
		console.log('Various parameters', pagination, filters, sorter);
		setSortedInfo(sorter);
	};
	const clearAll = () => {
		setSortedInfo({});
	};

	const styles = {
		statusTag: {
			borderRadius: '20px',
			paddingLeft: '10px',
			paddingRight: '10px'
		},
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		searchBox: {
			marginLeft: '16px'
		},
		firstColumn: {
			fontWeight: 500
		},
		column: {
			paddingBottom: '16px'
		}
	};

	let data = [
		{
			key: '1',
			vitalSigns: (
				<div style={styles.firstColumn}>
					{vitalSignslabels.respiratoryRate}
				</div>
			),
			firstEntries: '40',
			secondEntries: '20',
			thirdEntries: '68',
			fourthEntries: '46',
			fifthEntries: '24'
		},
		{
			key: '2',
			vitalSigns: (
				<div style={styles.firstColumn}>
					{vitalSignslabels.heartRate}
				</div>
			),
			firstEntries: '40',
			secondEntries: '20',
			thirdEntries: '68',
			fourthEntries: '46',
			fifthEntries: '24'
		},
		{
			key: '3',
			vitalSigns: (
				<div style={styles.firstColumn}>
					{vitalSignslabels.saturation}
				</div>
			),
			firstEntries: '40',
			secondEntries: '20',
			thirdEntries: '68',
			fourthEntries: '46',
			fifthEntries: '24'
		},
		{
			key: '4',
			vitalSigns: (
				<div style={styles.firstColumn}>
					{vitalSignslabels.temperature}
				</div>
			),
			firstEntries: '40',
			secondEntries: '20',
			thirdEntries: '68',
			fourthEntries: '46',
			fifthEntries: '24'
		},
		{
			key: '4',
			vitalSigns: (
				<div style={styles.firstColumn}>
					{vitalSignslabels.bloodPressure}
				</div>
			),
			firstEntries: '40/20/Normal',
			secondEntries: '40/20/Normal',
			thirdEntries: '40/20/Normal',
			fourthEntries: '40/20/Normal',
			fifthEntries: '40/20/Normal'
		}
	];

	const columns = [
		{
			title: labels.vitalSigns.toUpperCase(),
			width: 320,
			dataIndex: 'vitalSigns',
			key: 'vitalSigns',
			sorter: (a, b) => a.vitalSigns.length - b.vitalSigns.length,
			sortOrder:
				sortedInfo.columnKey === 'vitalSigns' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: '12/10/2020',
			dataIndex: 'firstEntries',
			key: 'firstEntries'
		},
		{
			title: '02/01/2021',
			dataIndex: 'secondEntries',
			key: 'secondEntries'
		},
		{
			title: '08/01/2021',
			dataIndex: 'thirdEntries',
			key: 'thirdEntries'
		},
		{
			title: '18/07/2022',
			dataIndex: 'fourthEntries',
			key: 'fourthEntries'
		},
		{
			title: '21/01/2023',
			dataIndex: 'fifthEntries',
			key: 'fifthEntries'
		}
	];

	const onSearch = (value) => {
		data = data.filter((record) => {
			let values = Object.values(record);
			let strValues = values.map((recordVal) => recordVal.toString());
			return strValues.some((text) => {
				text = text.toLowerCase();
				let matches = text.indexOf(value.toLowerCase()) >= 0;
				return matches;
			});
		});
	};

	const options = {
		responsive: true,
		plugins: {
			legend: {
				position: 'top'
			}
		}
	};

	const chartLabels = columns
		.filter((column) => column.dataIndex !== 'vitalSigns')
		.map((colData) => colData.title);

	const chartData = {
		labels: chartLabels,
		datasets: [
			{
				label: 'Dataset 1',
				data: Object.keys(data[0])
					.filter((key) => key !== 'key' && key !== 'vitalSigns')
					.map((key) => {
						return data[0][key];
					}),
				borderColor: 'rgb(255, 99, 132)',
				backgroundColor: 'rgba(255, 99, 132, 0.5)'
			}
		]
	};
	useEffect(() => {
		dispatch(getVitalSigns(patientId));
	}, [dispatch, patientId]);

	const showModal = () => {
		setOpen(true)
		console.log("hello wprld")
	}
	const handleCloseModal = () => {
		setOpen(false)
	}
	return (
		<div>
			<div style={styles.topActionButtons}>
				<Button
					type="primary"
					ghost
					icon={<CloseSquareOutlined />}
					onClick={clearAll}
				>
					Clear All Filter & Sort 
				</Button>
				<div style={styles.searchBox}>
					<Search
						placeholder="input search text"
						allowClear
						onSearch={onSearch}
					/>
				</div>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
				onClick={showModal}>
					ADD  
				</Button>
			</div>
			<Table
				columns={columns}
				dataSource={data}
				onChange={handleChange}
			/>
			<Row gutter={16}>
				{data.map((element) => {
					return (
						<Col span={8} key={element} style={styles.column}>
							<Card>
								<Meta title={element.vitalSigns} />
								<br />
								<Line options={options} data={chartData} />
							</Card>
						</Col>
					);
				})}
			</Row>
			{open && (
				<AddvitalSigns
					opened={open}
					handleClose={handleCloseModal}
					patientData = {patientData}
				/>
			)}
		</div>
	);
};

export default VitalSignsTabComponent;
