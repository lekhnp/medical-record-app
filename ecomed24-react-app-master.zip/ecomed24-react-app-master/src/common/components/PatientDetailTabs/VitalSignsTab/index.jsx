export { default } from './VitalSignsTabComponent';
