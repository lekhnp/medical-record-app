export { default } from './CurrentMedicationTabComponent';
