import { Button, Row, Col, Card } from 'antd';
import { AppstoreAddOutlined } from '@ant-design/icons';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getMedication } from '../../../../appStore/actions/medicationAction';
import CurruntMedicationModal from '../../../modal/CurruntMedicationModal/CurruntMedicationModal'

const { Meta } = Card;

const CurrentMedicationTabComponent = () => {
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const medicationData = useSelector((state) => state.medication.data);
	const [open, setOpen] = useState(false)
	const patientData = useSelector((state) => state.patientDetails.get.data);
 
	const styles = {
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		column: {
			paddingBottom: '16px'
		}
	};
	useEffect(() => {
		dispatch(getMedication(patientId));
	}, [dispatch, patientId]);

	const showModal = () => {
		setOpen(true)
	}
	const handleCancel = () => {
		setOpen(false)
	}
	return (
		<div>
			<div style={styles.topActionButtons}>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
					onClick={showModal}>
					ADD
				</Button>
			</div>
			<Row gutter={16}>
				{medicationData.length > 0 &&  medicationData?.map((element) => {
					return (
						<Col span={8} key={element} style={styles.column}>
							<Card>
								<Meta
									title={element?.content}
									description={`Date ${element?.date_time.split(' ')[0]} Time ${element?.date_time.split(' ')[1]} `}
								/>
							</Card>
						</Col>
					);
				})}
			</Row>
			{
				open && (<CurruntMedicationModal
					opened={open}
					handleClose={handleCancel}
					patientData = {patientData}
				/>)
			}
		</div>
	);
};

export default CurrentMedicationTabComponent;
