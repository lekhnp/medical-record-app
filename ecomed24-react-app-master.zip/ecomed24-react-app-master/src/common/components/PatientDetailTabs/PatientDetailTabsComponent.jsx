import { Card, Tabs } from 'antd';
import { useTranslation } from 'react-i18next';
import GeneralInfoTabComponent from './GeneralInfoTab';
import AppointmentsTabComponent from './AppointmentsTab';
import InvoicePaymentTabComponent from './InvoicePaymentTab';
import DependentTabComponent from './DependentTab';
import AssuranceTabComponent from './AssuranceTab';
import AttachmentsTabComponent from './AttachmentsTab';
import VitalSignsTabComponent from './VitalSignsTab';
import CurrentMedicationTabComponent from './CurrentMedicationTab';
import KnownHealthIssuesTabComponent from './KnownHealthIssuesTab';
import MedicalHistoryTabComponent from './MedicalHistoryTab';

const styles = {
	tabWrapper: {
		width: '100%',
		padding: '0',
		minHeight: '200px'
	},
	tabContent: { padding: '16px' }
};

const PatientDetailTabsComponent = () => {
	const { t } = useTranslation();
	const labels = t('patientDetailTabs', { returnObjects: true });
	const onChange = (key) => {
		console.log(key);
	};
	const items = [
		{
			key: 'generalInfo',
			label: labels.generalInfo.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<GeneralInfoTabComponent />
				</div>
			)
		},
		{
			key: 'appointments',
			label: labels.appointments.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<AppointmentsTabComponent />
				</div>
			)
		},
		{
			key: 'invoicesAndPayments',
			label: labels.invoicesAndPayments.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<InvoicePaymentTabComponent />
				</div>
			)
		},
		{
			key: 'dependent',
			label: labels.dependent.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<DependentTabComponent />
				</div>
			)
		},
		{
			key: 'assurance',
			label: labels.assurance.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<AssuranceTabComponent />
				</div>
			)
		},
		{
			key: 'attachments',
			label: labels.attachments.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<AttachmentsTabComponent />
				</div>
			)
		},
		{
			key: 'vitalSigns',
			label: labels.vitalSigns.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<VitalSignsTabComponent />
				</div>
			)
		},
		{
			key: 'currentMedication',
			label: labels.currentMedication.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<CurrentMedicationTabComponent />
				</div>
			)
		},
		{
			key: 'knowHealthIssues',
			label: labels.knowHealthIssues.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<KnownHealthIssuesTabComponent />
				</div>
			)
		},
		{
			key: 'medicalHistory',
			label: labels.medicalHistory.toUpperCase(),
			children: (
				<div style={styles.tabContent}>
					<MedicalHistoryTabComponent />
				</div>
			)
		}
	];

	return (
		<Card
			bordered={false}
			style={styles.tabWrapper}
			className="patientTabsWrapper"
		>
			<Tabs defaultActiveKey="1" items={items} onChange={onChange} />
		</Card>
	);
};

export default PatientDetailTabsComponent;
