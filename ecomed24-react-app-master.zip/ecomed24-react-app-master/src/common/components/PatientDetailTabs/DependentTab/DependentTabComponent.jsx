import { Table, Button, Input } from 'antd';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { AppstoreAddOutlined, CloseSquareOutlined } from '@ant-design/icons';
import { useParams } from 'react-router-dom';
import { getDependents } from '../../../../appStore/actions/dependentsAction';
import DependentModal from '../../../modal/DependentModal/DependentModal';

const { Search } = Input;

const DependentTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('dependentTab', { returnObjects: true });
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const [open, setOpen] = useState(false)
	const dependentData = useSelector((state) => state.dependents.data);

	const [sortedInfo, setSortedInfo] = useState({});
	const handleChange = (pagination, filters, sorter) => {
		console.log('Various parameters', pagination, filters, sorter);
		setSortedInfo(sorter);
	};
	console.log(dependentData)
	const clearAll = () => {
		setSortedInfo({});
	};
	const showModal = () => {
		setOpen(true)
	}
	const handleCloseModal = () => {
		setOpen(false)
	}
	const styles = {
		statusTag: {
			borderRadius: '20px',
			paddingLeft: '10px',
			paddingRight: '10px'
		},
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		searchBox: {
			marginLeft: '16px'
		}
	};

	const columns = [
		// {
		// 	title: labels.forename.toUpperCase(),
		// 	dataIndex: 'last_name',
		// 	key: 'last_name',
		// 	sorter: (a, b) => a.forename.length - b.forename.length,
		// 	sortOrder:
		// 		sortedInfo.columnKey === 'last_name' ? sortedInfo.order : null,
		// 	ellipsis: true
		// },
		{
			title: labels.name.toUpperCase(),
			dataIndex: 'name',
			key: 'name',
			sorter: (a, b) => a.name.length - b.name.length,
			sortOrder:
				sortedInfo.columnKey === 'name' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.dateOfBirth.toUpperCase(),
			dataIndex: 'birthdate',
			key: 'birthdate',
			sorter: (a, b) => a.service.length - b.service.length,
			sortOrder:
				sortedInfo.columnKey === 'birthdate'
					? sortedInfo.order
					: null,
			ellipsis: true
		},
		{
			title: labels.familyRelations.toUpperCase(),
			dataIndex: 'relation_type',
			key: 'relation_type',
			sorter: (a, b) =>
				a.familyRelations.length - b.familyRelations.length,
			sortOrder:
				sortedInfo.columnKey === 'relation_type'
					? sortedInfo.order
					: null,
			ellipsis: true
		}
	];

	const onSearch = (value) => {
		dependentData = dependentData.filter((record) => {
			let values = Object.values(record);
			let strValues = values.map((recordVal) => recordVal.toString());
			return strValues.some((text) => {
				text = text.toLowerCase();
				let matches = text.indexOf(value.toLowerCase()) >= 0;
				return matches;
			});
		});
	};

	useEffect(() => {
		dispatch(getDependents(patientId));
	}, [dispatch, patientId]);

	return (
		<div>
			<div style={styles.topActionButtons}>
				<Button
					type="primary"
					ghost
					icon={<CloseSquareOutlined />}
					onClick={clearAll}
				>
					Clear All Filter & Sort
				</Button>
				<div style={styles.searchBox}>
					<Search
						placeholder="input search text"
						allowClear
						onSearch={onSearch}
					/>
				</div>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined/>}onClick={showModal}>
					ADD
				</Button>
			</div>
			<Table
				columns={columns}
				dataSource={dependentData}
				onChange={handleChange}
			/>
			{open && (
				<DependentModal
					opened={open}
					handleClose={handleCloseModal}
				/>
			)}
		</div>
	);
};

export default DependentTabComponent;
