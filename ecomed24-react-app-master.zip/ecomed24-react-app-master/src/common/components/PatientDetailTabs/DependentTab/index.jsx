export { default } from './DependentTabComponent';
