export { default } from './InvoicePaymentTabComponent';
