import { Table, Button, Input } from 'antd';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import {
	AppstoreAddOutlined,
	CloseSquareOutlined,
	DollarCircleFilled,
	SnippetsFilled
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getInvoices } from '../../../../appStore/actions/invoicesAction';

const { Search } = Input;

const InvoicePaymentTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('invoicePaymentTab', { returnObjects: true });
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const invoiceData = useSelector((state) => state.invoices.data);

	const [filteredInfo, setFilteredInfo] = useState({});
	const [sortedInfo, setSortedInfo] = useState({});
	const handleChange = (pagination, filters, sorter) => {
		console.log('Various parameters', pagination, filters, sorter);
		setFilteredInfo(filters);
		setSortedInfo(sorter);
	};
	const clearAll = () => {
		setFilteredInfo({});
		setSortedInfo({});
	};

	const styles = {
		statusTag: {
			borderRadius: '20px',
			paddingLeft: '10px',
			paddingRight: '10px'
		},
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		searchBox: {
			marginLeft: '16px'
		}
	};

	let data = [
		{
			key: '1',
			date: '20/02/2023',
			receipt: 'CO25713001',
			amount: '0 FCFA',
			options: 'TBC'
		},
		{
			key: '2',
			date: '13/12/2022',
			receipt: 'F25712984',
			amount: '2,000 FCFA',
			options: 'Confirmed'
		}
	];

	// for (let i = 0; i < 100; i++) {
	// 	data.push({
	// 		key: (data.length + 1).toString(),
	// 		date: '10/01/2023',
	// 		receipt: 'F25712998',
	// 		amount: '25,000 FCFA',
	// 		options: 'Confirmed'
	// 	});
	// }

	const columns = [
		{
			title: labels.date.toUpperCase(),
			dataIndex: 'date',
			key: 'date',
			filters: [
				{
					text: '29/03/23',
					value: '29/03/23'
				},
				{
					text: '22/03/23',
					value: '22/03/23'
				}
			],
			filteredValue: filteredInfo.date || null,
			onFilter: (value, record) => record.date.includes(value),
			sorter: (a, b) => a.date.length - b.date.length,
			sortOrder:
				sortedInfo.columnKey === 'date' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.receipt.toUpperCase(),
			dataIndex: 'receipt',
			key: 'receipt',
			filters: [
				{
					text: '14:00 - 15:00',
					value: '14:00 - 15:00'
				}
			],
			filteredValue: filteredInfo.receipt || null,
			onFilter: (value, record) => record.receipt.includes(value),
			sorter: (a, b) => a.receipt.length - b.receipt.length,
			sortOrder:
				sortedInfo.columnKey === 'receipt' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.amount.toUpperCase(),
			dataIndex: 'amount',
			key: 'amount',
			filters: [
				{
					text: 'Medical Analysis Laboratory',
					value: 'Medical Analysis Laboratory'
				}
			],
			filteredValue: filteredInfo.amount || null,
			onFilter: (value, record) => record.amount.includes(value),
			sorter: (a, b) => a.amount.length - b.amount.length,
			sortOrder:
				sortedInfo.columnKey === 'amount' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.options.toUpperCase(),
			dataIndex: 'options',
			key: 'options',
			render: () => (
				<>
					<Button
						type="primary"
						icon={<SnippetsFilled />}
						size="small"
						style={{ marginRight: '12px' }}
					>
						Receipt
					</Button>
					<Button
						type="primary"
						size="small"
						icon={<DollarCircleFilled />}
					>
						Deposit
					</Button>
				</>
			)
		}
	];

	const onSearch = (value) => {
		data = data.filter((record) => {
			let values = Object.values(record);
			let strValues = values.map((recordVal) => recordVal.toString());
			return strValues.some((text) => {
				text = text.toLowerCase();
				let matches = text.indexOf(value.toLowerCase()) >= 0;
				return matches;
			});
		});
	};

	useEffect(() => {
		dispatch(getInvoices(patientId));
	}, [dispatch, patientId]);

	return (
		<div>
			<div style={styles.topActionButtons}>
				<Button
					type="primary"
					ghost
					icon={<CloseSquareOutlined />}
					onClick={clearAll}
				>
					Clear All Filter & Sort
				</Button>
				<div style={styles.searchBox}>
					<Search
						placeholder="input search text"
						allowClear
						onSearch={onSearch}
					/>
				</div>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}>
					ADD
				</Button>
			</div>
			<Table
				columns={columns}
				dataSource={data}
				onChange={handleChange}
			/>
		</div>
	);
};

export default InvoicePaymentTabComponent;
