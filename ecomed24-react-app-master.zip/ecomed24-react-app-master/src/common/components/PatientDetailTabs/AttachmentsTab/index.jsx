export { default } from './AttachmentsTabComponent';
