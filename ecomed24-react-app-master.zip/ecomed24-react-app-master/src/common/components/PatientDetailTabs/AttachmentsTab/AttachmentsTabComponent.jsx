import { Button, Row, Col, Card } from 'antd';
import { useEffect, useState } from 'react';
import {
	AppstoreAddOutlined,
	DeleteFilled,
	DownloadOutlined
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { deleteAttachment, getAttachments } from '../../../../appStore/actions/attachmentsAction';
import AttachmentModal from '../../../modal/AttachmentsModal/AttachmentModal';
import { downloadFile } from '../../../../utils/download';
import { getService } from '../../../../appStore/actions/helperAction';

const { Meta } = Card;

const AttachmentsTabComponent = () => {
	const [open, setOpen] = useState(false)
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const attachmentsData = useSelector((state) => state.attachments.data);
	const serviseData = useSelector((state)=>state?.helper.data)
	const styles = {
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		column: {
			paddingBottom: '16px'
		}
	};
	console.log('serviseData', serviseData)
	useEffect(() => {
		dispatch(getAttachments(patientId));
		dispatch(getService())
	}, [dispatch, patientId]);

	const showModal = () => {
		setOpen(true)
	}
	const handleCloseModal = () => {
		setOpen(false)
	}
	const hadnleDownload = (ele) => {
		console.log('download', ele)
		downloadFile(ele, 'attachmetn')
	}
	const handleDelete = (ele) => {
		let res = window.confirm("Do you want to delete ?")
		if (res) {
			dispatch(deleteAttachment(ele.id))
			console.log(res)
			dispatch(getAttachments(patientId))
		}
	}
	return (
		<div>
			<div style={styles.topActionButtons}>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
					onClick={showModal}>
					ADD
				</Button>
			</div>
			<Row gutter={16}>
				{attachmentsData?.map((element) => {
					return (
						<Col span={6} key={element} style={styles.column}>
							<Card
								cover={
									<img
										alt="example"
										src="https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png"
									/>
								}

								actions={[
									<DownloadOutlined key="download" onClick={() => hadnleDownload(element)} />,
									<DeleteFilled key="delete" onClick={() => handleDelete(element)} />
								]}
							>
								<Meta title={element.url} />
							</Card>
						</Col>
					);
				})}
			</Row>
			{open && (
				<AttachmentModal
					opened={open}
					handleClose={handleCloseModal}
					serviseData ={serviseData}
				/>
			)}
		</div>
	);
};

export default AttachmentsTabComponent;
