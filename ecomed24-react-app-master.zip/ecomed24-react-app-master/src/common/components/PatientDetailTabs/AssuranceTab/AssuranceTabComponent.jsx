import { Table, Button, Input } from 'antd';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { AppstoreAddOutlined, CloseSquareOutlined } from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import {  getAssurance,   } from '../../../../appStore/actions/assuranceAction';
import AssuranceModal from '../../../modal/AssuranceModal/AssuranceModal';
import { getAssuranceOrganition } from '../../../../appStore/actions/helperAction';

const { Search } = Input;

const AssuranceTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('assuranceTab', { returnObjects: true });
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const assuranceData = useSelector((state) => state.assurance.data);
	const assuranceorganiationData = useSelector((state) => state?.helper?.assuranceorganation?.data)
	const [sortedInfo, setSortedInfo] = useState({});
	const [open, setOpen] = useState(false)
	const handleChange = (pagination, filters, sorter) => {
		console.log('Various parameters', pagination, filters, sorter);
		setSortedInfo(sorter);
	};
	const clearAll = () => {
		setSortedInfo({});
	};
	console.log("assuranceorganiationData",assuranceorganiationData)
	const styles = {
		statusTag: {
			borderRadius: '20px',
			paddingLeft: '10px',
			paddingRight: '10px'
		},
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		searchBox: {
			marginLeft: '16px'
		}
	};

	const columns = [
		{
			title: labels.thirdPartyPayingName.toUpperCase(),
			dataIndex: 'payer_name',
			key: 'payer_name',
			sorter: (a, b) =>
				a.thirdPartyPayingName.length - b.thirdPartyPayingName.length,
			sortOrder:
				sortedInfo.columnKey === 'payer_name'
					? sortedInfo.order
					: null,
			ellipsis: true
		},
		{
			title: labels.policyNumber.toUpperCase(),
			dataIndex: 'pm_idmutuelle',
			key: 'pm_idmutuelle',
			sorter: (a, b) => a.policyNumber.length - b.policyNumber.length,
			sortOrder:
				sortedInfo.columnKey === 'pm_idmutuelle'
					? sortedInfo.order
					: null,
			ellipsis: true
		},
		{
			title: labels.support.toUpperCase(),
			dataIndex: 'pm_charge',
			key: 'pm_charge',
			sorter: (a, b) => a.support.length - b.support.length,
			sortOrder:
				sortedInfo.columnKey === 'pm_charge' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.validityDate.toUpperCase(),
			dataIndex: 'pm_datevalid',
			key: 'pm_datevalid',
			sorter: (a, b) => a.validityDate.length - b.validityDate.length,
			sortOrder:
				sortedInfo.columnKey === 'pm_datevalid'
					? sortedInfo.order
					: null,
			ellipsis: true
		}
	];

	const onSearch = (value) => {
		assuranceData = assuranceData.filter((record) => {
			let values = Object.values(record);
			let strValues = values.map((recordVal) => recordVal.toString());
			return strValues.some((text) => {
				text = text.toLowerCase();
				let matches = text.indexOf(value.toLowerCase()) >= 0;
				return matches;
			});
		});
	};

	useEffect(() => {
		dispatch(getAssurance(patientId));
	}, [dispatch, patientId]);
	useEffect(() => {
		dispatch(getAssuranceOrganition())
	}, [])
	const showModal = () => {
		setOpen(true)
	}
	const handleCancel = () => {
		setOpen(false)
	}
	return (
		<div>
			<div style={styles.topActionButtons}>
				<Button
					type="primary"
					ghost
					icon={<CloseSquareOutlined />}
					onClick={clearAll}
				>
					Clear All Filter & Sort
				</Button>
				<div style={styles.searchBox}>
					<Search
						placeholder="input search text"
						allowClear
						onSearch={onSearch}
					/>
				</div>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
					onClick={showModal}>
					ADD
				</Button>
			</div>
			<Table
				columns={columns}
				dataSource={assuranceData}
				onChange={handleChange}
			/>
			{open && (
				<AssuranceModal
					opened={open}
					handleClose={handleCancel}
					assuranceorganiationData={assuranceorganiationData} 
					/>
				
			)}
		</div>
	);
};

export default AssuranceTabComponent;
