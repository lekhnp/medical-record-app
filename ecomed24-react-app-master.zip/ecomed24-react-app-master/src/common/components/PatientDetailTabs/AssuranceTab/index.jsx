export { default } from './AssuranceTabComponent';
