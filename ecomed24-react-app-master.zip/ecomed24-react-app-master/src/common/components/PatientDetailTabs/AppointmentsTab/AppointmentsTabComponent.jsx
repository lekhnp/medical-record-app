import { Table, Tag, Button, Input } from 'antd';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { AppstoreAddOutlined, CloseSquareOutlined } from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { deleteAppointmet, getAppoinments } from '../../../../appStore/actions/appoinmentsAction';
import { format } from 'date-fns';
import AddappointmetnModal from '../../../modal/AppointmentAddModal/AddappointmetnModal';

const { Search } = Input;

const AppointmentsTabComponent = () => {
	const { t } = useTranslation();
	const labels = t('appointmentsTab', { returnObjects: true });
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const [open, setOpen] = useState(false);
	const appoinmentsData = useSelector((state) =>state?.appoinments?.data)
	const showModal = () => {
		setOpen(true);
	};
	const handleCancel = () => {
		setOpen(false);
	};


	// const appoinmentsData = useSelector((state) =>
	// 	state?.appoinments?.data.map((appoinment) => {
	// 		let date = '';
	// 		if (appoinment.date) {
	// 			const dateObj = new Date(parseInt(appoinment.date));
	// 			date = format(dateObj, 'dd/MM/yyyy');
	// 		}

	// 		return {
	// 			...appoinment,
	// 			key: appoinment.id,
	// 			date: date
	// 		};
	// 	})
	// );
	const handleDeleteAppointment = (value) => {
		let appointment_id = value.id
		let res = window.confirm("do you want to delete the Appointment")
		if (res) {
			dispatch(deleteAppointmet(appointment_id))
			dispatch(getAppoinments(patientId))
			if (deleteAppointmet.status === 1) {
				 
			}
		}

	}
	const [filteredInfo, setFilteredInfo] = useState({});
	const [sortedInfo, setSortedInfo] = useState({});
	const handleChange = (pagination, filters, sorter) => {
		console.log('Various parameters', pagination, filters, sorter);
		setFilteredInfo(filters);
		setSortedInfo(sorter);
	};
	const clearAll = () => {
		setFilteredInfo({});
		setSortedInfo({});
	};

	const styles = {
		statusTag: {
			borderRadius: '20px',
			paddingLeft: '10px',
			paddingRight: '10px'
		},
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		searchBox: {
			marginLeft: '16px'
		}
	};

	const columns = [
		{
			title: labels.date.toUpperCase(),
			dataIndex: 'date',
			key: 'date',
			filters: [
				{
					text: '29/03/23',
					value: '29/03/23'
				},
				{
					text: '22/03/23',
					value: '22/03/23'
				}
			],
			filteredValue: filteredInfo.date || null,
			onFilter: (value, record) => record.date.includes(value),
			sorter: (a, b) => a.date.length - b.date.length,
			sortOrder:
				sortedInfo.columnKey === 'date' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.schedule.toUpperCase(),
			dataIndex: 'time_slot',
			key: 'time_slot',
			filters: [
				{
					text: '14:00 - 15:00',
					value: '14:00 - 15:00'
				},
				{
					text: '15:00 - 16:00',
					value: '15:00 - 16:00'
				}
			],
			filteredValue: filteredInfo.time_slot || null,
			onFilter: (value, record) => record.time_slot.includes(value),
			sorter: (a, b) => a.time_slot.length - b.time_slot.length,
			sortOrder:
				sortedInfo.columnKey === 'time_slot' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: labels.service.toUpperCase(),
			dataIndex: 'servicename',
			key: 'servicename',
			filters: [
				{
					text: 'Medical Analysis Laboratory',
					value: 'Medical Analysis Laboratory'
				}
			],
			filteredValue: filteredInfo.servicename || null,
			onFilter: (value, record) => record.servicename.includes(value),
			sorter: (a, b) => a.servicename.length - b.servicename.length,
			sortOrder:
				sortedInfo.columnKey === 'servicename'
					? sortedInfo.order
					: null,
			ellipsis: true
		},
		{
			title: labels.status.toUpperCase(),
			dataIndex: 'status',
			key: 'status',
			render: (_, { status }) => (
				<Tag
					color={
						status === 'Pending Confirmation' ? 'orange' : 'green'
					}
					style={styles.statusTag}
				>
					{status}
				</Tag>
			),
			filters: [
				{
					text: 'TBC',
					value: 'TBC'
				},
				{
					text: 'Confirmed',
					value: 'Confirmed'
				}
			],
			filteredValue: filteredInfo.status || null,
			onFilter: (value, record) => record.status.includes(value),
			sorter: (a, b) => a.status.length - b.status.length,
			sortOrder:
				sortedInfo.columnKey === 'status' ? sortedInfo.order : null,
			ellipsis: true
		},
		{
			title: 'Action',
			key: 'action',
			render: (_, value) => (
				<span>
					<a style={{ color: "red" }} onClick={() => handleDeleteAppointment(value)}>Delete</a>
				</span>
			),
		},
	];


	const onSearch = (value) => {
		appoinmentsData = appoinmentsData.filter((record) => {
			let values = Object.values(record);
			let strValues = values.map((recordVal) => recordVal.toString());
			return strValues.some((text) => {
				text = text.toLowerCase();
				let matches = text.indexOf(value.toLowerCase()) >= 0;
				return matches;
			});
		});
	};

	useEffect(() => {
		dispatch(getAppoinments(patientId));
	}, [dispatch, patientId]);

	return (
		<div>
			<div style={styles.topActionButtons}>
				<Button
					type="primary"
					ghost
					icon={<CloseSquareOutlined />}
					onClick={clearAll}
				>
					Clear All Filter & Sort
				</Button>
				<div style={styles.searchBox}>
					<Search
						placeholder="input search text"
						allowClear
						onSearch={onSearch}
					/>
				</div>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
					onClick={showModal}
				>
					ADD
				</Button>
			</div>
			<Table
				columns={columns}
				dataSource={appoinmentsData}
				onChange={handleChange}
			/>
			{open && (
				<AddappointmetnModal
					opened={open}
					handleClose={handleCancel}
				/>
			)}
		</div>
	);
};

export default AppointmentsTabComponent;
