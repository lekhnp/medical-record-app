export { default } from './AppointmentsTabComponent';
