export { default } from './KnownHealthIssuesTabComponent';
