import { Button, Row, Col, Card } from 'antd';
import { AppstoreAddOutlined } from '@ant-design/icons';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { getHealthIssues } from '../../../../appStore/actions/healthIssuesAction';
import KnowhealthModal from '../../../modal/KnowHealthModal/KnowhealthModal';

const { Meta } = Card;

const KnownHealthIssuesTabComponent = () => {
	const { patientId } = useParams();
	const dispatch = useDispatch();
	const healthIssuesData = useSelector((state) => state.healthIssues.data);
	const patientData = useSelector((state) => state.patientDetails.get.data);
	const [open, setOpen] = useState(false)
	const styles = {
		topActionButtons: {
			display: 'flex',
			paddingBottom: '16px'
		},
		spacer: {
			flex: '1'
		},
		column: {
			paddingBottom: '16px'
		}
	};
 

	useEffect(() => {
		dispatch(getHealthIssues(patientId));
	}, [dispatch, patientId]);

	console.log("healthIssuesData",healthIssuesData)
	const handleShowModal = () => {
		setOpen(true)
	}
	const handleCancel = () => {
		setOpen(false)
	}
	return (
		<div>
			<div style={styles.topActionButtons}>
				<div style={styles.spacer}></div>
				<Button type="primary" icon={<AppstoreAddOutlined />}
					onClick={handleShowModal}>
					ADD
				</Button>
			</div>
			<Row gutter={16}>
				{healthIssuesData.map((element) => {
					return (
						<Col span={8} key={element} style={styles.column}>
							<Card>
								<Meta
									title={element?.content}
									description={`Date ${element?.date_time.split(' ')[0]} Time ${element?.date_time.split(' ')[1]} `}
								/>
							</Card>
						</Col>
					);
				})}
			</Row>
			{
				open && (<KnowhealthModal
					opened={open}
					handleClose={handleCancel}
					patientData = {patientData}
				/>)
			}
		</div>
	);
};

export default KnownHealthIssuesTabComponent;
