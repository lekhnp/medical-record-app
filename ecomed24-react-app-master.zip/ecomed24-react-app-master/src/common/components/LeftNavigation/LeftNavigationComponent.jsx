import { Menu } from 'antd';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import MENU_ITEMS from './MenuConstant';

const LeftNavigationComponent = () => {
	const { t } = useTranslation();

	const getItems = (items) => {
		return items.map((item) => {
			let label = t('leftNav', { returnObjects: true })[item.key];
			return {
				key: item.key,
				icon: item.icon,
				children:
					item.children.length > 0
						? getItems(item.children) // recursive call
						: undefined,
				label: item.link ? (
					item.linkType === 'external' ? (
						<a href={item.link}>{label}</a>
					) : (
						<Link to={item.link}>{label}</Link>
					)
				) : (
					<span>{label}</span>
				)
			};
		});
	};

	const items = getItems(MENU_ITEMS);

	return (
		<Menu
			theme="dark"
			defaultSelectedKeys={['1']}
			mode="inline"
			items={items}
		/>
	);
};

export default LeftNavigationComponent;
