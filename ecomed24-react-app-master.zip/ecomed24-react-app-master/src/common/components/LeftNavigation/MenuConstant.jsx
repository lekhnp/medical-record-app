import {
	HomeFilled,
	CalendarFilled,
	ContactsFilled,
	IdcardFilled,
	CreditCardFilled,
	ContainerFilled,
	ProfileFilled,
	ScheduleFilled,
	FileTextFilled,
	FundFilled,
	PlusCircleFilled,
	AlipayCircleFilled,
	MedicineBoxFilled,
	SafetyCertificateFilled,
	SlidersFilled,
	EditFilled,
	SignalFilled
} from '@ant-design/icons';

const BASE_PATH = 'http://35.175.173.189/';

const MENU_ITEMS = [
	{
		link: `${BASE_PATH}home`,
		linkType: 'external',
		key: 'home',
		icon: <HomeFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}appointment/calendar`,
		linkType: 'external',
		key: 'calendar',
		icon: <CalendarFilled />,
		children: []
	},
	{
		link: '',
		linkType: '',
		key: 'patients',
		icon: <IdcardFilled />,
		children: [
			{
				link: `${BASE_PATH}patient`,
				linkType: 'external',
				key: 'listOfPatients',
				icon: <ContactsFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}patient/patientPayments`,
				linkType: 'external',
				key: 'patientPayments',
				icon: <CreditCardFilled />,
				children: []
			}
		]
	},
	{
		link: '',
		linkType: '',
		key: 'schedule',
		icon: <ScheduleFilled />,
		children: [
			{
				link: `${BASE_PATH}horaire`,
				linkType: 'external',
				key: 'service',
				icon: <ContainerFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}horaire/employe`,
				linkType: 'external',
				key: 'doctor',
				icon: <ContactsFilled />,
				children: []
			}
		]
	},
	{
		link: '',
		linkType: '',
		key: 'appoinment',
		icon: <ProfileFilled />,
		children: []
	},
	{
		link: '',
		linkType: '',
		key: 'acts',
		icon: <FundFilled />,
		children: [
			{
				link: `${BASE_PATH}finance/paymentLabo`,
				linkType: 'external',
				key: 'listOfActs',
				icon: <FileTextFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/addPaymentView`,
				linkType: 'external',
				key: 'addAnAct',
				icon: <PlusCircleFilled />,
				children: []
			}
		]
	},
	{
		link: `${BASE_PATH}sanitaire`,
		linkType: 'external',
		key: 'healthReport',
		icon: <AlipayCircleFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}finance/paymentCategory`,
		linkType: 'external',
		key: 'benefits',
		icon: <MedicineBoxFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}finance/insurance`,
		linkType: 'external',
		key: 'thirdPartyPayers',
		icon: <SafetyCertificateFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}partenaire`,
		linkType: 'external',
		key: 'partners',
		icon: <SlidersFilled />,
		children: []
	},
	{
		link: '',
		linkType: '',
		key: 'invoicing',
		icon: <ProfileFilled />,
		children: [
			{
				link: `${BASE_PATH}partenaire/listeFacturePrestation`,
				linkType: 'external',
				key: 'invoicePartner',
				icon: <ProfileFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}partenaire/factures`,
				linkType: 'external',
				key: 'listOfInvoices',
				icon: <ProfileFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}partenaire/facturesRapport`,
				linkType: 'external',
				key: 'performanceReport',
				icon: <ProfileFilled />,
				children: []
			}
		]
	},
	{
		link: '',
		linkType: '',
		key: 'services',
		icon: <ScheduleFilled />,
		children: [
			{
				link: `${BASE_PATH}finance/expense`,
				linkType: 'external',
				key: 'listOfExpenses',
				icon: <ScheduleFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/addExpenseView`,
				linkType: 'external',
				key: 'addAnExpenses',
				icon: <PlusCircleFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/expenseCategory`,
				linkType: 'external',
				key: 'categoriesOfExpenditure',
				icon: <EditFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/serviceCategory`,
				linkType: 'external',
				key: 'categoriesOfServices',
				icon: <EditFilled />,
				children: []
			}
		]
	},
	{
		link: `${BASE_PATH}prescription/all`,
		linkType: 'external',
		key: 'ordinance',
		icon: <AlipayCircleFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}prescription/transferedPrescription`,
		linkType: 'external',
		key: 'transferOrder',
		icon: <AlipayCircleFilled />,
		children: []
	},
	{
		link: `${BASE_PATH}prescription/genererDocument`,
		linkType: 'external',
		key: 'generateDocument',
		icon: <AlipayCircleFilled />,
		children: []
	},
	{
		link: '',
		linkType: '',
		key: 'commerce',
		icon: <FundFilled />,
		children: [
			{
				link: `${BASE_PATH}finance/financialReport`,
				linkType: 'external',
				key: 'financialReport',
				icon: <ScheduleFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/monthly`,
				linkType: 'external',
				key: 'recipesPerMonth',
				icon: <FundFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/daily`,
				linkType: 'external',
				key: 'recipesPerDay',
				icon: <FundFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/monthlyExpense`,
				linkType: 'external',
				key: 'expensesPerMonth',
				icon: <SignalFilled />,
				children: []
			},
			{
				link: `${BASE_PATH}finance/dailyExpense`,
				linkType: 'external',
				key: 'expensesPerDay',
				icon: <SignalFilled />,
				children: []
			}
		]
	}
];

// function getItem(label, key, icon, children) {
//     return {
//       key,
//       icon,
//       children,
//       label
//     };
// }

// const items = [
//     getItem(<Link to="organization-management">Organization Management</Link>, '1', <PieChartOutlined />),
//     getItem('Data Management', 'sub1', <PieChartOutlined />, [
//         getItem(<Link to="service-and-specialties">Service & Sepcialties</Link>, '2', <PieChartOutlined />),
//         getItem(<Link to="benefits">Benefits</Link>, '3', <PieChartOutlined />),
//     ]),
//     getItem('Medicine', 'sub2', <PieChartOutlined />, [
//         getItem(<Link to="list-of-medicine">List of Main Medicine</Link>, '4', <PieChartOutlined />),
//         getItem(<Link to="new-drug">New Drug</Link>, '5', <PieChartOutlined />)
//     ]),
// ];

export default MENU_ITEMS;
