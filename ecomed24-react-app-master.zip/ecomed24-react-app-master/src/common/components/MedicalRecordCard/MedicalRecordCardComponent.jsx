import { useState } from 'react';
import { Card, Row, Col, Typography, Button } from 'antd';
import { useTranslation } from 'react-i18next';
import { useSelector, useDispatch } from 'react-redux';
import man_avatar1 from '../../../assets/avatar/man_avatar1.png';
import { EditFilled } from '@ant-design/icons';
import EditMedicalRecordModalComponent from '../../modal/EditMedicalRecordModal/EditMedicalRecordModalComponent';
import { UPDATE_PATIENT_DETAILS_RESET } from '../../../appStore/actions/patientDetailsAction';

const { Title, Text } = Typography;

const styles = {
	col1: {
		marginRight: '30px'
	},
	col2: {
		marginRight: '80px'
	},
	patientTitle: {
		marginTop: '5px',
		marginBottom: '5px'
	},
	modifyButton: {
		marginTop: '6px',
		textTransform: 'uppercase'
	},
	patientInfo: {
		marginTop: '8px',
		textTransform: 'uppercase'
	},
	strongText: {
		fontWeight: '500'
	}
};

const MedicalRecordCardComponent = () => {
	const { t } = useTranslation();
	const labels = t('medicalRecordCard', { returnObjects: true });
	const patientData = useSelector((state) => state.patientDetails.get.data);
	const [open, setOpen] = useState(false);
	const dispatch = useDispatch();

	const showModal = () => {
		dispatch({ type: UPDATE_PATIENT_DETAILS_RESET });
		setOpen(true);
	};

	const handleCancel = () => {
		setOpen(false);
	};
	return (
		patientData && (
			<>
				<Card
					title={`${labels.headerTitle} | ${patientData.name}`}
					bordered={false}
					style={{
						width: '100%'
					}}
				>
					<Row>
						<Col style={styles.col1}>
							<img
								src={man_avatar1}
								width={100}
								alt={labels.profileAvatar}
							/>
						</Col>
						<Col style={styles.col2}>
							<Title level={4} style={styles.patientTitle}>
								{patientData.name}
							</Title>
							<div>
								<Text strong>{patientData.register}</Text>
							</div>
							<Button
								type="primary"
								shape="round"
								icon={<EditFilled />}
								size="small"
								style={styles.modifyButton}
								onClick={showModal}
							>
								{labels.modifyProfile}
							</Button>
						</Col>
						<Col style={styles.col2}>
							<div style={styles.patientInfo}>
								{patientData.code && (
									<Text>
										{labels.code} :{' '}
										<span style={styles.strongText}>
											{patientData.code}
										</span>
									</Text>
								)}
							</div>
							<div style={styles.patientInfo}>
								<Text>
									{labels.gender} :{' '}
									<span style={styles.strongText}>
										{patientData.gender}
									</span>
								</Text>
							</div>
							<div style={styles.patientInfo}>
								<Text>
									{labels.age} :{' '}
									<span style={styles.strongText}>
										{patientData.age && (
											<>{patientData.age} years</>
										)}
									</span>
								</Text>
							</div>
						</Col>
						<Col>
							<div style={styles.patientInfo}>
								<Text>
									{labels.lastAppointment} :{' '}
									<span style={styles.strongText}>
										{patientData.last_appointment}
									</span>
								</Text>
							</div>
							<div style={styles.patientInfo}>
								<Text>
									{labels.nextAppointment} :{' '}
									<span style={styles.strongText}>
										{patientData.next_appointment}
									</span>
								</Text>
							</div>
						</Col>
					</Row>
				</Card>
				{open && (
					<EditMedicalRecordModalComponent
						opened={open}
						handleClose={handleCancel}
						patientDetails={patientData}
					/>
				)}
			</>
		)
	);
};

export default MedicalRecordCardComponent;
