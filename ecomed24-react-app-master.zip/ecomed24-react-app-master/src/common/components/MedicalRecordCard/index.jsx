export { default } from './MedicalRecordCardComponent';
