import React from 'react';
import logo from '../../../assets/logo.png';

import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons';
const styles = {
	logo: {
		marginLeft: '10px',
		width: '100px'
	},
	icon: {
		fontSize: '20px'
	}
};
const HeaderComponent = (props) => {
	const { onMenuClick, collapsed } = props;
	return (
		<div>
			{React.createElement(
				collapsed ? MenuUnfoldOutlined : MenuFoldOutlined,
				{
					className: 'trigger',
					onClick: () => onMenuClick()
				}
			)}{' '}
			<img src={logo} alt="logo" style={styles.logo} />
		</div>
	);
};

export default HeaderComponent;
