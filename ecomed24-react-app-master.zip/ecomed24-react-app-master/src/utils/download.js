

export const downloadFile = (response, fileName) => {
    if (response) {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', fileName || 'sample'); //or any other extension
        document.body.appendChild(link);
        link.click();
        alert("downloaded sucessfuly")
    }
};
