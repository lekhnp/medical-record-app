export const GENDER = [
    { value: 'Masculin', option: 'Masculine' },
    { value: 'Feminin', option: 'Feminine' }
];

export const REGION = [
    {value: 'Dakar', option: 'Dakar'}, 
    {value: 'Ziguinchor', option: 'Ziguinchor'},
    {value: 'Diourbel', option: 'Diourbel'}, 
    {value: 'Saint-Louis', option: 'Saint-Louis'}, 
    {value: 'Tambacounda', option: 'Tambacounda'},
    {value: 'Kaolack', option: 'Kaolack'}, 
    {value: 'Thiès', option: 'Thiès'}, 
    {value: 'Louga', option: 'Louga'},
    {value: 'Fatick', option: 'Fatick'}, 
    {value: 'Kolda', option: 'Kolda'}, 
    {value: 'Matam', option: 'Matam'}, 
    {value: 'Kaffrine', option: 'Kaffrine'},
    {value: 'Kédougou', option: 'Kédougou'}, 
    {value: 'Sédhiou', option: 'Sédhiou'},
];

export const BLOOD_TYPE = [
    { value: 'A+', option: 'A+' },
    { value: 'A-', option: 'A-' },
    { value: 'B+', option: 'B+' },
    { value: 'B-', option: 'B-' },
    { value: 'AB+', option: 'AB+' },
    { value: 'AB-', option: 'AB-' },
    { value: 'O+', option: 'O+' },
    { value: 'O-', option: 'O-' }
]

export const RELIGION = [
    { value: 'Musulmane', option: 'Musulmane' },
    { value: 'Chetienne', option: 'Chetienne' },
    { value: 'Autres', option: 'Autres' }
]

export const PENDING_CONFERMITION = [
    { value: 'Pending Confirmation', option: 'Pending Confirmation' },
    { value: 'Confirmed', option: 'Confirmed' }
]
export const SERVICES = [
    { value: "Ophtalmologie", option: "Ophtalmologie" },
    { value: "Laboratoire d'Analyses Médicales", option: "Laboratoire d'Analyses Médicales" },
]
export const AVILABLE_SLOTS = [
    { value: "", option: "select" },
    { value: "6:00-7:00", option: "6:00-7:00" },
    { value: "7:00-8:00", option: "7:00-8:00" },
    { value: "8:00-9:00", option: "8:00-9:00" },
    { value: "9:00-10:00", option: "9:00-10:00" },
    { value: "10:00-11:00", option: "10:00-11:00" },
    { value: "11:00-12:00", option: "11:00-12:00" },
    { value: "12:00-13:00", option: "12:00-13:00" },
    { value: "13:00-14:00", option: "13:00-14:00" },
    { value: "14:00-15:00", option: "14:00-15:00" },
    { value: "15:00-16:00", option: "15:00-16:00" },
    { value: "16:00-17:00", option: "16:00-17:00" },
    { value: "17:00-18:00", option: "17:00-18:00" },
]
export const RELATIONSHIP = [
    {value :"mother" ,option:"Mother"},
    {value:"father", option:"Father"},
    {value:"child", option:"Child"},

]