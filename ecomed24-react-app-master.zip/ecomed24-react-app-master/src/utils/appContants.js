export const APP_API_URL = "http://35.175.173.189:2001";

