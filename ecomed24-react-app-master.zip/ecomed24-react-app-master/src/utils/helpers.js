export const getLocalStorageData = () => {
    let data = {};
    if (localStorage.length > 0) {
        data = {
            token: localStorage.getItem("token")
        };
    }

    return data;
};
  
export const setRequestHeader = (type) => {
    let loggedInInfo = getLocalStorageData();
    let headerObj = {};

    if (loggedInInfo.token) {
        headerObj.Authorization = `Bearer ${loggedInInfo.token}`;
    }

    if(type === "urlencoded") {
        headerObj["Content-Type"] = "application/x-www-form-urlencoded;charset=UTF-8";
    }

    return headerObj;
};