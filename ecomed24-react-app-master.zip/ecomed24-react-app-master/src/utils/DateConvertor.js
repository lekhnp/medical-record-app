
export const  dateConvertor = (dateString)=> {
    dateString = dateString['$d']
    let dateObject = new Date(dateString);
    let day = dateObject.getDate(); // Get the day (1-31)
    let monthIndex = dateObject.getMonth(); // Get the month (0-11, where 0 represents January)
    let year = dateObject.getFullYear(); // Get the full year (e.g., 2023)
    let  months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    let month = months[monthIndex];
    let  convertedDate = day + '/' + (monthIndex + 1) + '/' + year;
    return convertedDate
}
