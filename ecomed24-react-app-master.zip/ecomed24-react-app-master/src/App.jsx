import { createHashRouter, RouterProvider } from 'react-router-dom';

import BenefitsModule from './modules/DataManagement/Benefits';
import ServiceAndSpecialtiesModule from './modules/DataManagement/ServiceAndSpecialties';
import ListOfMainMedicineModule from './modules/Medicine/ListOfMainMedicine';
import NewDrugModule from './modules/Medicine/NewDrug';
import OrganizationManagementModule from './modules/OrganizationManagement';
import LayoutWrapperModule from './modules/LayoutWrapper';
import PatientsDetails from './modules/Patients/PatientsDetails';

import './App.css';

const router = createHashRouter([
	{
		element: <LayoutWrapperModule />,
		children: [
			{
				path: '/:token?',
				element: <OrganizationManagementModule />
			},
			{
				path: '/benefits/:token?',
				element: <BenefitsModule />
			},
			{
				path: '/service-and-specialties/:token?',
				element: <ServiceAndSpecialtiesModule />
			},
			{
				path: '/list-of-medicine/:token?',
				element: <ListOfMainMedicineModule />
			},
			{
				path: '/new-drug/:token?',
				element: <NewDrugModule />
			},
			{
				path: '/organization-management/:token?',
				element: <OrganizationManagementModule />
			},

			{
				path: '/patients-details/:patientId/:token?',
				element: <PatientsDetails />
			}
		]
	}
]);

const App = () => {
	return <RouterProvider router={router} />;
};

export default App;
