const ServiceAndSpecialtiesModule = () => {
	return <div>Data Management &gt; Service And Specialties</div>;
};

export default ServiceAndSpecialtiesModule;
