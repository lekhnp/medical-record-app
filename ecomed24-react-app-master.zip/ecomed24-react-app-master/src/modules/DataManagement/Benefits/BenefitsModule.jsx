const BenefitsModule = () => {
	return <div>Data Management &gt; Benefits</div>;
};

export default BenefitsModule;
