export { default } from './PatientsDetailsModule';
