import { useEffect } from 'react';
import { Row, Col } from 'antd';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import MedicalRecordCardComponent from '../../../common/components/MedicalRecordCard';
import PatientDetailTabsComponent from '../../../common/components/PatientDetailTabs';
import { getPatientDetails } from '../../../appStore/actions/patientDetailsAction';

const PatientsDetailsModule = () => {
	const { patientId } = useParams();
	const dispatch = useDispatch();

	const colStyle = {
		padding: '16px'
	};

	useEffect(() => {
		dispatch(getPatientDetails(patientId));
	}, [dispatch, patientId]);

	return (
		<Row>
			<Col span={24} style={colStyle}>
				<MedicalRecordCardComponent />
			</Col>
			<Col span={24} style={colStyle}>
				<PatientDetailTabsComponent />
			</Col>
		</Row>
	);
};

export default PatientsDetailsModule;
