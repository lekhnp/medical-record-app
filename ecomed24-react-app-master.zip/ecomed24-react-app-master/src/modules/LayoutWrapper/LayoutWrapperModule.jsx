import { Outlet, useParams } from 'react-router-dom';
import { Layout, theme } from 'antd';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';

import HeaderComponent from '../../common/components/Header';
import FooterComponent from '../../common/components/Footer';
import LeftNavigation from '../../common/components/LeftNavigation';

const { Header, Content, Sider } = Layout;

const LayoutWrapperModule = () => {
	const { token } = useParams();
	const [collapsed, setCollapsed] = useState(false);
	const {
		token: { colorBgContainer }
	} = theme.useToken();

	const auth = useSelector((state) => state.auth);

	const redirectUrl = 'http://35.175.173.189/auth/login';

	const authenticateUser = () => {
		if (token) {
			localStorage.setItem('token', token);
		}
		let storedToken = localStorage.getItem('token');
		if (!storedToken) {
			window.location.assign(redirectUrl);
		}
	};

	authenticateUser();

	useEffect(() => {
		if (auth.message === 'Failed to authenticate token.') {
			window.location.assign(redirectUrl);
		}
	}, [auth, redirectUrl]);

	return (
		<Layout className="container">
			<Header style={{ background: colorBgContainer }}>
				<HeaderComponent
					onMenuClick={() => {
						setCollapsed(!collapsed);
					}}
					collapsed={collapsed}
				/>
			</Header>
			<Layout>
				<Sider width={240} collapsed={collapsed}>
					<LeftNavigation />
				</Sider>
				<Layout>
					<Content>
						<Outlet />
						<FooterComponent />
					</Content>
				</Layout>
			</Layout>
		</Layout>
	);
};

export default LayoutWrapperModule;
