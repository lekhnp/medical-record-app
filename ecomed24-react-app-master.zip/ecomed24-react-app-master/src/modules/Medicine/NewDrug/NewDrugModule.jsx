const NewDrugModule = () => {
	return <div>Medicine &gt; New Drug</div>;
};

export default NewDrugModule;
