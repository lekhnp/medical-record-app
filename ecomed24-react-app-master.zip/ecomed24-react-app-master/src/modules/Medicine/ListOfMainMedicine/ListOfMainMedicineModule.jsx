const ListOfMainMedicineModule = () => {
	return <div>Medicine &gt; List Of Main Medicine</div>;
};

export default ListOfMainMedicineModule;
